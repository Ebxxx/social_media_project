

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>User Profile</h2>

    <!-- Show profile picture if it exists -->
    <?php if($user->profile && $user->profile->profile_picture): ?>
        <img src="<?php echo e(asset('storage/profile_pictures/' . $user->profile->profile_picture)); ?>" alt="Profile Picture" style="width:150px; height:150px;">
    <?php else: ?>
        <p>No profile picture uploaded.</p>
    <?php endif; ?>

    <!-- Profile update form -->
    <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="profile_picture">Upload Profile Picture</label>
            <input type="file" class="form-control" name="profile_picture">
        </div>

        <div class="form-group">
            <label for="bio">Bio</label>
            <textarea name="bio" class="form-control"><?php echo e($user->profile ? $user->profile->bio : ''); ?></textarea>
        </div>

        <div class="form-group">
            <label for="address">Address</label>
            <input type="text" name="address" class="form-control" value="<?php echo e($user->profile ? $user->profile->address : ''); ?>">
        </div>

        <div class="form-group">
            <label for="phone_number">Phone Number</label>
            <input type="text" name="phone_number" class="form-control" value="<?php echo e($user->profile ? $user->profile->phone_number : ''); ?>">
        </div>

        <button type="submit" class="btn btn-primary">Update Profile</button>
    </form>

    <?php if(session('success')): ?>
        <div class="alert alert-success mt-3"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\social_media_project\New folder\social-media\resources\views/profile/show.blade.php ENDPATH**/ ?>