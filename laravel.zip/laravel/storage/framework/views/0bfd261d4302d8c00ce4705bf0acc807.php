<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Profile</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <h1>User Profile</h1>
    <p><strong>Name:</strong> <?php echo e($user->name); ?></p>
    <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
    <p><strong>Bio:</strong> <?php echo e($user->bio); ?></p>

    <a href="<?php echo e(route('profile.edit')); ?>">Edit Profile</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\social_media_app\resources\views/profile/view.blade.php ENDPATH**/ ?>