

<?php $__env->startSection('content'); ?>
    <h1>Profile</h1>
    
    <div>
        <strong>Name:</strong> <?php echo e($user->name); ?>

    </div>
    
    <div>
        <strong>Email:</strong> <?php echo e($user->email); ?>

    </div>

    <a href="<?php echo e(route('profile.edit')); ?>">Edit Profile</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\social_media_app\resources\views/profile/show.blade.php ENDPATH**/ ?>