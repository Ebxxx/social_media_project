<div>
    <!-- If you do not have a consistent goal in life, you can not live it in a consistent way. - Marcus Aurelius -->
</div><?php /**PATH C:\xampp\htdocs\social_media_app\resources\views/components/button.blade.php ENDPATH**/ ?>